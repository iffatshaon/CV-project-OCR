These are the steps to run the codes:

1. pip install -r requirements.txt
2. Run extract.py -- Database will be extracted to specific folder
3. Run All in separate.ipynb -- Model training separately on Bangla and English Dataset
4. Run All in combined.ipynb -- Combine models and create a combined training
5. You will get all the export files